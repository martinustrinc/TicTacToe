public class Board {

    // To print out the board. e.g : 3 x 3
	/*
	| 1 | 2 | 3 |
	| 4 | 5 | 6 |
	| 7 | 8 | 9 |
	*/

    static void printBoardAdjustable(int range, String[] board) {

        System.out.println(" ");
//        for (int i = 0; i < range; i++) {
//            System.out.print("|----|");
//        }
//        System.out.println();
        for (int i = 0; i < board.length; i++) {
            System.out.print("| " + board[i] + " | ");
            if (i >= range) {
                if ((i + 1) % range == 0) {
                    System.out.println(" ");
                }
            } else {
                if (i == range - 1) {
                    System.out.println(" ");
                }
            }
        }
//        for (int i = 0; i < range; i++) {
//            System.out.print("|----|");
//        }
//        System.out.println();
        System.out.println(" ");
    }
}
