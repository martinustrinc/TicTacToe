import java.util.*;

// Tic-Tac-Toe Game.
public class main {

    static String[] board;
    static int range;
    static String turn;
    static String player;

    public static void main(String[] args) {

        System.out.println("Welcome to Tic Tac Toe Game.");

        Scanner in = new Scanner(System.in);
        System.out.print("Please Input your type of range Tic-Tac-Toe (e.g : 3x3 just input 3) : ");
        range = in.nextInt();
        board = new String[range*range];
//        board = new String[9];
        turn = "X";
        String winner = null;

        for (int a = 0; a < board.length; a++) {
            board[a] = String.valueOf(a + 1);
        }

        System.out.println("Playing Tic Tac Toe in Range : "+range+"x"+range+ " with 2 Player.");
//        Board.printBoard(board);
        Board.printBoardAdjustable(range, board);

        System.out.print(
                "Player 1 will play first. Enter a slot number to place X in : ");

        while (winner == null) {
            int numInput;

            // Exception handling.
            // numInput will take input from user like from 1 to 9.
            // If it is not in range from 1 to 9.
            // then it will show you an error "Invalid input."
            try {
                numInput = in.nextInt();
                if (!(numInput > 0 && numInput <= board.length)) {
                    System.out.println(
                            "Invalid input; re-enter slot number:");
                    continue;
                }
            }
            catch (InputMismatchException e) {
                System.out.println(
                        "Invalid input; re-enter slot number:");
                continue;
            }

            // This game has two player x and O.
            // Here is the logic to decide the turn.
            if (board[numInput - 1].equals(
                    String.valueOf(numInput))) {
                board[numInput - 1] = turn;

                if (turn.equals("X")) {
                    turn = "O";
                    player = "Player 2";
                }
                else {
                    turn = "X";
                    player = "Player 1";
                }

//                Board.printBoard(board);
                Board.printBoardAdjustable(range, board);
                winner = CheckWinner.checkWinner(board, player, turn);
            }
            else {
                System.out.println(
                        "Slot already taken; re-enter slot number:");
            }
        }

        // If no one win or lose from both player x and O.
        // then here is the logic to print "draw".
        if (winner.equalsIgnoreCase("draw")) {
            System.out.println(
                    "It's a draw! Thanks for playing.");
        }

        // For winner -to display Congratulations! message.
        else {
            System.out.println(
                    "Congratulations! " + winner
                            + "'s have won! Thanks for playing.");
        }
    }
}
